package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Customer;

@Controller
public class URIController {

	private Customer customer;

	@RequestMapping(value= {"/","index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/customerRegistration")
	public String getRegistrationPage() {
		return "customerRegistrationPage";
	}
	@RequestMapping("/customerDetails")
	public String getCustomerDetailsPage() {
		return "GetCustomerDetails";
	}
	@RequestMapping("/allCustomersDetails")
	public String getAllCustomersDetailsPage() {
		return "getallCustomerDetails";
	}
	@RequestMapping("/deleteCustomersDetails")
	public String getdeleteCustomersDetailsPage() {
		return "deleteCustomerPage";
	}
	@ModelAttribute
	public Customer getAssociate() {
	customer = new Customer();
		return customer;
	}
}
