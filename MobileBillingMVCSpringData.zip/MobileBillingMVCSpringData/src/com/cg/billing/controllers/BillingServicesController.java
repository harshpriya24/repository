package com.cg.billing.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
public class BillingServicesController {
	@Autowired
	private BillingServices services;
	
	@RequestMapping("/registerCustomer")
	public ModelAndView registerAssociate(@Valid@ModelAttribute Customer customer,BindingResult result) {
		if(result.hasErrors()) return new ModelAndView("customerRegistrationPage");
		customer=services.acceptCustomerDetails(customer);
		return new ModelAndView("customerRegistrationSuccessPage","customer",customer);
	}
	@RequestMapping("/getCustomerDetails")
	public ModelAndView getCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException {
		Customer customer=services.getCustomerDetails(customerID);
		return new ModelAndView("getCustomerDetailsSuccessPage","customer",customer);
	}
	@RequestMapping("/allCustomerDetails")
	public ModelAndView getAllCustomerDetails(){
		List<Customer> customers=services.getAllCustomerDetails();
		return new ModelAndView("getallCustomerDetails","customers",customers);
	}
	@RequestMapping("/deleteCustomer")
	public ModelAndView getdeleteCustomer(@RequestParam int customerID) throws CustomerDetailsNotFoundException{
		boolean result=services.removeCustomerDetails(customerID);
		return new ModelAndView("deleteCustomerSuccessPage","result",result);
	}
	
}
